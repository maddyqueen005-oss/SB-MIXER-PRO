# SB MIXER PRO Native Android v1.2

## এই সংস্করণে কী আছে
- Kotlin native Android project (Android 10 / API 29 বা নতুন)
- 12টি channel-strip UI; CH01-এ Android Playback Capture input prototype
- CH01-এর পাঁচটি independent peaking EQ band: SUB 52 Hz, BASS 105 Hz, LOW MID 250 Hz, MID 1 kHz, HIGH 8 kHz
- Master EQ, master level, channel fader, foreground service ও live CH01 output meter
- 0 dB-তে EQ filter unity response রাখে; EQ gain অন্য band-এর gain setting বদলায় না

## গুরুত্বপূর্ণ সীমাবদ্ধতা
1. Android Playback Capture কেবল সেই অ্যাপের অডিও পাবে যেগুলো capture অনুমোদন করে। YouTube/অন্য অ্যাপ সবসময় capture হবে—এমন নিশ্চয়তা নেই।
2. Playback Capture মূল অ্যাপের অডিও বন্ধ বা intercept করে না। একই ফোনের speaker-এ original এবং processed output একসঙ্গে শোনা যেতে পারে; headphones দিয়ে পরীক্ষা করুন।
3. UI-তে 12টি strip আছে, কিন্তু v1.2 prototype-এ কেবল CH01 Playback Capture audio engine-এ যুক্ত। CH02–CH12 এখন input-slot placeholder; file player/mic routing পরের ধাপ।
4. এটি প্রাথমিক prototype, professional concert-grade sound বা zero-noise guarantee নয়। বাস্তব ফোনে latency, clipping, noise ও thermal পরীক্ষা আবশ্যক।
5. বর্তমান DSP হলো পাঁচটি peaking EQ এবং soft clipping। Compressor, limiter, stem separation, per-band FFT energy share, true 12-channel summing এবং background local-file playback এখনো সম্পূর্ণ হয়নি।

## Android ফোন থেকেই APK build
1. ZIP extract করুন।
2. GitHub-এ নতুন repository তৈরি করে এই project-এর সব ফাইল upload করুন।
3. GitHub Actions চালু করুন; `.github/workflows/android-build.yml` workflow `main` branch-এ push হলেই build করবে।
4. Actions → Build SB Mixer APK → Artifacts থেকে `SB-MIXER-PRO-debug-apk` ডাউনলোড করুন।
5. ZIP extract করে APK ইনস্টল করুন। Android-এ unknown-app installation অনুমতি লাগতে পারে।

## Local build (Android Studio / PC)
JDK 17 ও Android SDK 35 দিয়ে:
`gradle assembleDebug`
APK: `app/build/outputs/apk/debug/app-debug.apk`

## Source
প্রধান Activity: `app/src/main/java/com/sbmixer/pro/MainActivity.kt`
Audio capture + DSP service: `app/src/main/java/com/sbmixer/pro/PlaybackCaptureService.kt`


## Per-channel EQ update v1.3
প্রতিটি Channel strip-এর ভিতরে SUB 52 Hz, BASS 105 Hz, LOW MID 250 Hz, MID 1 kHz ও HIGH 8 kHz-এর আলাদা gain slider রাখা হয়েছে। প্রতিটি Channel-এর Fader ও EQ settings আলাদা করে রাখা হয়। বর্তমান prototype-এ Playback Capture audio input শুধু CH01-এ যায়; CH02–CH12-এর প্রকৃত input routing পরবর্তী কাজ। UI-তে LEVEL / ENERGY readout placeholder আছে; live per-band telemetry এখনো সব Channel-এ চালু নয়।
