package com.sbmixer.pro

import android.app.*
import android.content.Intent
import android.media.*
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.IBinder
import android.content.pm.ServiceInfo
import kotlin.concurrent.thread
import kotlin.math.*

class PlaybackCaptureService : Service() {
    companion object {
        const val ACTION_LEVEL = "com.sbmixer.pro.LEVEL"
        const val EXTRA_RESULT_CODE = "resultCode"
        const val EXTRA_RESULT_DATA = "resultData"
        const val ACTION_UPDATE = "com.sbmixer.pro.UPDATE"
        @Volatile private var instance: PlaybackCaptureService? = null

        fun update(ctx: android.content.Context, master: Float? = null, fader: Float? = null,
                   eq: FloatArray? = null, channelBand: Int? = null, channelGain: Float? = null) {
            val i = Intent(ctx, PlaybackCaptureService::class.java).setAction(ACTION_UPDATE)
            master?.let { i.putExtra("master", it) }
            fader?.let { i.putExtra("fader", it) }
            eq?.let { i.putExtra("eq", it) }
            channelBand?.let { i.putExtra("channelBand", it) }
            channelGain?.let { i.putExtra("channelGain", it) }
            ctx.startService(i)
        }
    }

    @Volatile private var running = false
    @Volatile private var masterGain = .8f
    @Volatile private var faderGain = .8f
    @Volatile private var eqGains = FloatArray(5)
    @Volatile private var channelGains = FloatArray(5)
    private var projection: MediaProjection? = null
    private var recorder: AudioRecord? = null
    private var player: AudioTrack? = null
    private var worker: Thread? = null
    private val sampleRate = 48000
    private val bands = doubleArrayOf(52.0, 105.0, 250.0, 1000.0, 8000.0)
    private val q = doubleArrayOf(1.0, .85, .8, .75, .7)
    private lateinit var filtersL: Array<Biquad>
    private lateinit var filtersR: Array<Biquad>
    private lateinit var chFiltersL: Array<Biquad>
    private lateinit var chFiltersR: Array<Biquad>

    override fun onCreate() {
        super.onCreate()
        instance = this
        createNotification()
    }

    private fun createNotification() {
        val channelId = "sb_mixer_audio"
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(channelId, "SB Mixer Audio Engine", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
        val n = Notification.Builder(this, channelId)
            .setContentTitle("SB MIXER PRO")
            .setContentText("Playback capture audio engine is running")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setOngoing(true).build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(7, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else startForeground(7, n)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_UPDATE) {
            intent.getFloatExtra("master", Float.NaN).takeUnless { it.isNaN() }?.let { masterGain = it }
            intent.getFloatExtra("fader", Float.NaN).takeUnless { it.isNaN() }?.let { faderGain = it }
            intent.getFloatArrayExtra("eq")?.let { if (it.size == 5) eqGains = it }
            val band = intent.getIntExtra("channelBand", -1)
            if (band in 0..4) channelGains[band] = intent.getFloatExtra("channelGain", 0f)
            return START_NOT_STICKY
        }
        if (!running) {
            val code = intent?.getIntExtra(EXTRA_RESULT_CODE, ActivityResult.RESULT_CANCELED) ?: ActivityResult.RESULT_CANCELED
            @Suppress("DEPRECATION")
            val data: Intent? = intent?.getParcelableExtra(EXTRA_RESULT_DATA)
            if (code == ActivityResult.RESULT_OK && data != null) startCapture(code, data)
            else stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun startCapture(resultCode: Int, data: Intent) {
        try {
            val mgr = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            projection = mgr.getMediaProjection(resultCode, data)
            projection?.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() { stopEngine() }
            }, android.os.Handler(mainLooper))

            val config = AudioPlaybackCaptureConfiguration.Builder(projection!!)
                .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
                .addMatchingUsage(AudioAttributes.USAGE_GAME)
                .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN)
                .build()
            val format = AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setSampleRate(sampleRate).setChannelMask(AudioFormat.CHANNEL_IN_STEREO).build()
            val min = AudioRecord.getMinBufferSize(sampleRate, AudioFormat.CHANNEL_IN_STEREO, AudioFormat.ENCODING_PCM_16BIT)
            recorder = AudioRecord.Builder().setAudioFormat(format).setBufferSizeInBytes(max(min * 2, 8192))
                .setAudioPlaybackCaptureConfig(config).build()

            val outFormat = AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setSampleRate(sampleRate).setChannelMask(AudioFormat.CHANNEL_OUT_STEREO).build()
            val outMin = AudioTrack.getMinBufferSize(sampleRate, AudioFormat.CHANNEL_OUT_STEREO, AudioFormat.ENCODING_PCM_16BIT)
            player = AudioTrack.Builder().setAudioAttributes(
                AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build()
            ).setAudioFormat(outFormat).setBufferSizeInBytes(max(outMin * 2, 8192))
                .setTransferMode(AudioTrack.MODE_STREAM).build()

            filtersL = Array(5) { Biquad(sampleRate.toDouble()) }
            filtersR = Array(5) { Biquad(sampleRate.toDouble()) }
            chFiltersL = Array(5) { Biquad(sampleRate.toDouble()) }
            chFiltersR = Array(5) { Biquad(sampleRate.toDouble()) }
            running = true
            recorder?.startRecording()
            player?.play()
            worker = thread(name = "SBMixerAudio", priority = Thread.MAX_PRIORITY) { audioLoop() }
        } catch (e: Exception) {
            sendBroadcast(Intent(ACTION_LEVEL).setPackage(packageName).putExtra("share", 0f))
            stopEngine()
        }
    }

    private fun audioLoop() {
        val input = ShortArray(1024 * 2)
        val output = ShortArray(1024 * 2)
        var lastMeter = System.nanoTime()
        while (running) {
            val count = recorder?.read(input, 0, input.size) ?: -1
            if (count <= 0) continue
            var sum = 0.0
            var peak = 0.0
            val frames = count / 2
            for (i in 0 until frames) {
                var l = input[i * 2] / 32768.0
                var r = input[i * 2 + 1] / 32768.0
                for (b in 0..4) {
                    chFiltersL[b].setPeaking(bands[b], q[b], channelGains[b].toDouble())
                    chFiltersR[b].setPeaking(bands[b], q[b], channelGains[b].toDouble())
                    l = chFiltersL[b].process(l); r = chFiltersR[b].process(r)
                }
                for (b in 0..4) {
                    filtersL[b].setPeaking(bands[b], q[b], eqGains[b].toDouble())
                    filtersR[b].setPeaking(bands[b], q[b], eqGains[b].toDouble())
                    l = filtersL[b].process(l); r = filtersR[b].process(r)
                }
                val gain = (masterGain * faderGain).coerceIn(0f, 1.5f).toDouble()
                l = tanh(l * gain); r = tanh(r * gain)
                sum += l*l + r*r
                peak = max(peak, max(abs(l), abs(r)))
                output[i * 2] = (l.coerceIn(-1.0, 1.0) * 32767).roundToInt().toShort()
                output[i * 2 + 1] = (r.coerceIn(-1.0, 1.0) * 32767).roundToInt().toShort()
            }
            player?.write(output, 0, frames * 2)
            val now = System.nanoTime()
            if (now - lastMeter > 100_000_000L) {
                val rms = if (frames > 0) sqrt(sum / (frames * 2)) else 0.0
                sendBroadcast(Intent(ACTION_LEVEL).setPackage(packageName)
                    .putExtra("share", if (rms > 0.00001) 100f else 0f)
                    .putExtra("level", if (rms > 0.000001) 20 * log10(rms) else -120.0)
                    .putExtra("peak", peak))
                lastMeter = now
            }
        }
    }

    private fun stopEngine() {
        running = false
        try { recorder?.stop() } catch (_: Exception) {}
        try { player?.pause(); player?.flush(); player?.stop() } catch (_: Exception) {}
        recorder?.release(); recorder = null
        player?.release(); player = null
        try { projection?.stop() } catch (_: Exception) {}
        projection = null
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        stopEngine()
        instance = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private object ActivityResult { const val RESULT_CANCELED = 0; const val RESULT_OK = -1 }

    private class Biquad(private val rate: Double) {
        private var b0=1.0; private var b1=0.0; private var b2=0.0
        private var a1=0.0; private var a2=0.0
        private var x1=0.0; private var x2=0.0; private var y1=0.0; private var y2=0.0
        private var lastGain = Double.NaN
        fun setPeaking(freq: Double, q: Double, gainDb: Double) {
            if (gainDb == lastGain) return
            lastGain = gainDb
            val A = 10.0.pow(gainDb / 40.0)
            val w = 2.0 * Math.PI * freq / rate
            val alpha = sin(w) / (2.0 * q)
            val c = cos(w)
            val aa0 = 1.0 + alpha / A
            b0 = (1.0 + alpha * A) / aa0
            b1 = (-2.0 * c) / aa0
            b2 = (1.0 - alpha * A) / aa0
            a1 = (-2.0 * c) / aa0
            a2 = (1.0 - alpha / A) / aa0
        }
        fun process(x: Double): Double {
            val y = b0*x + b1*x1 + b2*x2 - a1*y1 - a2*y2
            x2=x1; x1=x; y2=y1; y1=y
            return y
        }
    }
}
