package com.sbmixer.pro

import android.app.Activity
import android.content.*
import android.graphics.Color
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import android.graphics.Typeface

class MainActivity : Activity() {
    private val requestCapture = 4102
    private lateinit var status: TextView
    private lateinit var ch01Share: TextView
    private var serviceRunning = false

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun label(text: String, size: Float = 12f, color: Int = 0xFFD9E5EA.toInt()): TextView =
        TextView(this).apply { this.text = text; textSize = size; setTextColor(color) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(8, 14, 19)
        window.navigationBarColor = Color.rgb(8, 14, 19)
        buildUi()
        if (android.os.Build.VERSION.SDK_INT >= 33) {
            registerReceiver(levelReceiver, IntentFilter(PlaybackCaptureService.ACTION_LEVEL), RECEIVER_NOT_EXPORTED)
        } else {
            @Suppress("DEPRECATION")
            registerReceiver(levelReceiver, IntentFilter(PlaybackCaptureService.ACTION_LEVEL))
        }
    }

    override fun onDestroy() {
        try { unregisterReceiver(levelReceiver) } catch (_: Exception) {}
        super.onDestroy()
    }

    private val levelReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            val pct = intent?.getFloatExtra("share", 0f) ?: 0f
            ch01Share.text = "OUTPUT ${"%.1f".format(pct)}%"
            status.text = if (pct > 0.05f) "CAPTURE ACTIVE · LIVE SIGNAL" else "CAPTURE ACTIVE · WAITING FOR AUDIO"
        }
    }

    private fun buildUi() {
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(12), dp(12), dp(12))
            setBackgroundColor(Color.rgb(9, 15, 21))
        }
        page.addView(label("SB MIXER PRO", 22f, 0xFF55E3D1.toInt()).apply { typeface = Typeface.DEFAULT_BOLD })
        page.addView(label("NATIVE ANDROID · 12 INPUT CHANNELS", 10f, 0xFF91A6B0.toInt()))
        status = label("ENGINE STOPPED", 12f, 0xFF79E6A5.toInt())
        status.setPadding(0, dp(10), 0, dp(8))
        page.addView(status)

        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val start = Button(this).apply { text = "CAPTURE OTHER APP AUDIO" }
        val stop = Button(this).apply { text = "STOP ENGINE" }
        actions.addView(start, LinearLayout.LayoutParams(0, dp(48), 1f))
        actions.addView(stop, LinearLayout.LayoutParams(0, dp(48), 1f))
        page.addView(actions)
        start.setOnClickListener {
            val mgr = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            startActivityForResult(mgr.createScreenCaptureIntent(), requestCapture)
        }
        stop.setOnClickListener {
            stopService(Intent(this, PlaybackCaptureService::class.java))
            serviceRunning = false
            status.text = "ENGINE STOPPED"
        }

        val note = label(
            "Android playback capture works only for source apps that allow capture. It does not replace or mute the original app audio. Use headphones to avoid hearing the original and processed audio together.",
            11f, 0xFFFFD18A.toInt()
        )
        note.setPadding(0, dp(8), 0, dp(10))
        page.addView(note)

        page.addView(label("MASTER SECTION · OUTPUT", 13f).apply { setPadding(0, dp(8), 0, dp(6)); typeface = Typeface.DEFAULT_BOLD })
        val master = SeekBar(this).apply { max = 100; progress = 80 }
        page.addView(label("MASTER LEVEL"))
        page.addView(master)
        master.setOnSeekBarChangeListener(simpleListener { PlaybackCaptureService.update(this, master = it / 100f) })

        page.addView(label("MASTER 5-BAND EQ · ZERO dB = FLAT", 13f).apply { setPadding(0, dp(10), 0, dp(6)); typeface = Typeface.DEFAULT_BOLD })
        val eqNames = listOf("SUB 52 Hz", "BASS 105 Hz", "LOW MID 250 Hz", "MID 1 kHz", "HIGH 8 kHz")
        val eqBars = mutableListOf<SeekBar>()
        eqNames.forEachIndexed { i, name ->
            val gainLabel = label("$name  ·  0.0 dB")
            page.addView(gainLabel)
            val seek = SeekBar(this).apply { max = 48; progress = 24 }
            page.addView(seek)
            seek.setOnSeekBarChangeListener(simpleListener {
                val gain = (it - 24) * 0.5f
                gainLabel.text = "$name  ·  ${if (gain > 0) "+" else ""}${"%.1f".format(gain)} dB"
                val values = eqBars.map { bar -> (bar.progress - 24) * 0.5f }.toFloatArray()
                PlaybackCaptureService.update(this, eq = values)
            })
            eqBars.add(seek)
        }
        val reset = Button(this).apply { text = "RESET EQ TO 0 dB" }
        page.addView(reset)
        reset.setOnClickListener { eqBars.forEach { it.progress = 24 }; PlaybackCaptureService.update(this, eq = FloatArray(5)) }

        page.addView(label("INPUT CHANNELS · 01—12", 14f).apply { setPadding(0, dp(14), 0, dp(8)); typeface = Typeface.DEFAULT_BOLD })
        val horizontal = HorizontalScrollView(this).apply { isFillViewport = false; horizontalScrollBarEnabled = true }
        val strips = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        for (n in 1..12) {
            val strip = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_HORIZONTAL
                setPadding(dp(8), dp(8), dp(8), dp(8))
                setBackgroundColor(Color.rgb(27, 39, 48))
            }
            val lp = LinearLayout.LayoutParams(dp(164), dp(590))
            lp.setMargins(0, 0, dp(8), 0)
            strips.addView(strip, lp)
            strip.addView(label("● INPUT %02d".format(n), 11f, 0xFF65E8A0.toInt()))
            strip.addView(label(if (n == 1) "PLAYBACK CAPTURE" else "INPUT SLOT", 12f))
            if (n == 1) {
                ch01Share = label("OUTPUT 0.0%", 12f, 0xFF55E3D1.toInt())
                strip.addView(ch01Share)
            } else {
                strip.addView(label("OUTPUT 0.0%", 12f, 0xFF9CB2BC.toInt()))
            }
            strip.addView(label("CHANNEL FADER"))
            val fader = SeekBar(this).apply { max = 100; progress = 80 }
            strip.addView(fader)
            if (n == 1) fader.setOnSeekBarChangeListener(simpleListener { PlaybackCaptureService.update(this, fader = it / 100f) })
            else fader.isEnabled = false

            listOf("SUB", "BASS", "LOW MID", "MID", "HIGH").forEachIndexed { idx, band ->
                strip.addView(label("$band  ${if (n == 1) "0.0 dB" else "—"}", 10f))
                val bar = SeekBar(this).apply { max = 48; progress = 24; isEnabled = n == 1 }
                strip.addView(bar)
                if (n == 1) bar.setOnSeekBarChangeListener(simpleListener {
                    val g = (it - 24) * .5f
                    val vals = FloatArray(5)
                    // CH01 strip controls are independent; these are applied as the CH01 input EQ.
                    vals[idx] = g
                    PlaybackCaptureService.update(this, channelBand = idx, channelGain = g)
                })
            }
            strip.addView(label(if (n == 1) "LIVE CAPTURE INPUT" else "SOURCE NOT CONNECTED", 9f, 0xFFFFC477.toInt()))
        }
        horizontal.addView(strips)
        page.addView(horizontal, LinearLayout.LayoutParams(-1, dp(610)))

        val scroll = ScrollView(this)
        scroll.addView(page)
        setContentView(scroll)
    }

    private fun simpleListener(onChange: (Int) -> Unit) = object : SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) { if (fromUser) onChange(progress) }
        override fun onStartTrackingTouch(seekBar: SeekBar?) {}
        override fun onStopTrackingTouch(seekBar: SeekBar?) {}
    }

    @Deprecated("Deprecated in Android API")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == requestCapture && resultCode == RESULT_OK && data != null) {
            val i = Intent(this, PlaybackCaptureService::class.java).apply {
                putExtra(PlaybackCaptureService.EXTRA_RESULT_CODE, resultCode)
                putExtra(PlaybackCaptureService.EXTRA_RESULT_DATA, data)
            }
            if (android.os.Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
            serviceRunning = true
            status.text = "STARTING PLAYBACK CAPTURE…"
        }
    }
}
